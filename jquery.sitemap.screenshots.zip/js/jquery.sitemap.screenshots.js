(function( $ ) {
 
	$.fn.slider = function( options ) {
		
		var el=this;
		
		var opts = {
				  lines: 13, // The number of lines to draw
				  length: 20, // The length of each line
				  width: 10, // The line thickness
				  radius: 30, // The radius of the inner circle
				  corners: 1, // Corner roundness (0..1)
				  rotate: 0, // The rotation offset
				  direction: 1, // 1: clockwise, -1: counterclockwise
				  color: '#000', // #rgb or #rrggbb or array of colors
				  speed: 1, // Rounds per second
				  trail: 60, // Afterglow percentage
				  shadow: false, // Whether to render a shadow
				  hwaccel: false, // Whether to use hardware acceleration
				  className: 'spinner', // The CSS class to assign to the spinner
				  zIndex: 2e9, // The z-index (defaults to 2000000000)
				  top: 200, // Top position relative to parent in px
				  left: 220 // Left position relative to parent in px
				};
				
	
		var spinner = new Spinner(opts);
	
	
        var settings = $.extend({           
            sitemap: "/sitemap.xml",           
        }, options );
       
        $.get(settings.sitemap,function(data){
        	
    		var links = [];	
    		 
    		 $(data).find('loc').each(function(index){			 
    			 links[index]=$($(this)).text();			 
    		 });
    		 
    	var length=links.length;
    	
    	var i=0;
    	
    	$(el).wrap('<div class="slider-wrapper"><div class="slider-viewport"></div><div class="slider-controls slider-has-controls-direction"><div class="slider-controls-direction"><a class="slider-prev">Prev</a><a class="slider-next">Next</a></div></div></div>');
    	$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');  
    	
    	spinner.spin($(el).get(0));
    	
    	$('.screenframe').load(function(){    		
    		var target=$(this).contents().find('body');        	
        		
        	html2canvas(target, {
        	    onrendered: function(canvas) {
        	    	var data = canvas.toDataURL();        	    	
        	    	$(el).append('<p><a href="'+links[i]+'">Go to</a></p><img class="screenshot" src="'+data+'"/>')
        	    	$('.screenshot').load(function(){        	
                    	spinner.stop();        	
                    	});
        	    }
        	});       	
    	});
    	
    	

    $('.slider-next').click(function() {		
    	i=i+1;	
    	if(i<length){
    	$(el).empty();		
$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');  
    	
    	spinner.spin($(el).get(0));
    	
    	$('.screenframe').load(function(){    		
    		var target=$(this).contents().find('body');        	
        		
        	html2canvas(target, {
        	    onrendered: function(canvas) {
        	    	var data = canvas.toDataURL();        	    	
        	    	$(el).append('<p><a href="'+links[i]+'">Go to</a></p><img class="screenshot" src="'+data+'"/>')
        	    	$('.screenshot').load(function(){        	
                    	spinner.stop();        	
                    	});
        	    }
        	});       	
    	});
    	
    	
    	}else{
    		i=length-1;
    		$(el).empty();		
    		$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');  
        	
        	spinner.spin($(el).get(0));
        	
        	$('.screenframe').load(function(){    		
        		var target=$(this).contents().find('body');        	
            		
            	html2canvas(target, {
            	    onrendered: function(canvas) {
            	    	var data = canvas.toDataURL();        	    	
            	    	$(el).append('<p><a href="'+links[i]+'">Go to</a></p><img class="screenshot" src="'+data+'"/>')
            	    	$('.screenshot').load(function(){        	
                        	spinner.stop();        	
                        	});
            	    }
            	});       	
        	});
    	}
    });

    $('.slider-prev').click(function() {		
    	i=i-1;
    	if(i>0){
    	$(el).empty();		
$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');  
    	
    	spinner.spin($(el).get(0));
    	
    	$('.screenframe').load(function(){    		
    		var target=$(this).contents().find('body');        	
        		
        	html2canvas(target, {
        	    onrendered: function(canvas) {
        	    	var data = canvas.toDataURL();        	    	
        	    	$(el).append('<p><a href="'+links[i]+'">Go to</a></p><img class="screenshot" src="'+data+'"/>')
        	    	$('.screenshot').load(function(){        	
                    	spinner.stop();        	
                    	});
        	    }
        	});       	
    	});
    	}else{
    		i=0;
    		$(el).empty();		
    		$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');  
        	
        	spinner.spin($(el).get(0));
        	
        	$('.screenframe').load(function(){    		
        		var target=$(this).contents().find('body');        	
            		
            	html2canvas(target, {
            	    onrendered: function(canvas) {
            	    	var data = canvas.toDataURL();        	    	
            	    	$(el).append('<p><a href="'+links[i]+'">Go to</a></p><img class="screenshot" src="'+data+'"/>')
            	    	$('.screenshot').load(function(){        	
                        	spinner.stop();        	
                        	});
            	    }
            	});       	
        	});
    	}
    });

    	});
        
        return this;
 
    };
}( jQuery ));